print("Xin chào 2024")
print("Tôi Yêu Việt Nam")
print("1234567890")
print("Chào tạm biệt")