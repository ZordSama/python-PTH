a = int(input("nhập vào a: "))
b = int(input("nhập vào b: "))
print("a + b =", a + b)
